#pragma once


// Class to contain generic PID algorithm.
class PID_c {
  public:
  
    // Constructor, must exist.
    PID_c() {

    } 

};
